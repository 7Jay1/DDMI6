package br.edu.ifsp.ddm.menu;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CalculadoraActivity extends AppCompatActivity {

    private EditText editN01;
    private EditText editN02;

    private TextView txtResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.calculadora_layout);

        editN01 = (EditText) findViewById(R.id.editN01);

        editN02 = (EditText) findViewById(R.id.editN02);

        txtResultado = findViewById(R.id.txtResultado);

    }

    public void somar(View v)
    {
        int n01, n02, res;
        n01 = Integer.parseInt(editN01.getText().toString());
        n02 = Integer.parseInt(editN02.getText().toString());

        res = n01 + n02 ;

        txtResultado.setText("resustado desta soma é: "+res);
    }

    public void subtrair(View v)
    {
        int n01, n02, res;
        n01 = Integer.parseInt(editN01.getText().toString());
        n02 = Integer.parseInt(editN02.getText().toString());

        res = n01 - n02 ;

        txtResultado.setText("resustado desta subtração é: "+res);

    }

    public void dividir(View v)
    {
        int n01, n02, res;
        n01 = Integer.parseInt(editN01.getText().toString());
        n02 = Integer.parseInt(editN02.getText().toString());

        res = n01 / n02 ;

        txtResultado.setText("resustado desta divisão é: "+res);
    }

    public void multiplicar(View v)
    {
        int n01, n02, res;
        n01 = Integer.parseInt(editN01.getText().toString());
        n02 = Integer.parseInt(editN02.getText().toString());

        res = n01 * n02 ;

        txtResultado.setText("resustado desta multiplicação é: "+res);
    }

}