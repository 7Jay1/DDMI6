package br.edu.ifsp.ddm.menu;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class CombustivelActivity extends AppCompatActivity {

    private EditText editN01;
    private EditText editN02;

    private TextView txtResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.combustivel_layout);

        editN01 = (EditText) findViewById(R.id.editN01);

        editN02 = (EditText) findViewById(R.id.editN02);

        txtResultado = findViewById(R.id.txtResultado);

    }

    public void combustível(View v)
    {
        double n01, n02, res;
        n01 = Double.parseDouble(editN01.getText().toString());
        n02 = Double.parseDouble(editN02.getText().toString());

        res = n01 / n02 ;

        if(res <= 0.7){
            txtResultado.setText("O Etanol é mais Recomendado");
        } else {
            txtResultado.setText("A Gasolina é mais Recomendado");
        }


    }
}