package br.edu.ifsp.ddm.menu;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void exibirCombustivel(View v)
    {
        Intent it = new Intent(this, CombustivelActivity.class );
        startActivity(it);
    }

    public void exibirIMC(View v)
    {
        Intent it = new Intent(this, IMCActivity.class );
        startActivity(it);
    }

    public void exibirCalculadora(View v)
    {
        Intent it = new Intent(this, CalculadoraActivity.class );
        startActivity(it);
    }

    public void exibirRelativeLayout(View v)
    {
        Intent it = new Intent(this, MediaActivity.class );
        startActivity(it);
    }
}