package br.edu.ifsp.ddm.menu;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.triangulo.databinding.ActivityMainBinding;

public class TrianguloActivity extends AppCompatActivity {

    private EditText editN01;
    private EditText editN02;

    private TextView txtResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editN01 = (EditText) findViewById(R.id.editN01);

        editN02 = (EditText) findViewById(R.id.editN02);

        txtResultado = findViewById(R.id.txtResultado);

    }

    public void area(View v)
    {
        int n01, n02, res;
        n01 = Integer.parseInt(editN01.getText().toString());
        n02 = Integer.parseInt(editN02.getText().toString());

        res = (n01 * n02)/2 ;

        txtResultado.setText("A area deste triângulo é: "+res);
    }

}