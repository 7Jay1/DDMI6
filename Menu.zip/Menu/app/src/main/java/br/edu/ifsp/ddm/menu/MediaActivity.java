package br.edu.ifsp.ddm.menu;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MediaActivity extends AppCompatActivity {

    private EditText editN01;
    private EditText editN02;
    private EditText editN03;
    private EditText editN04;

    private TextView txtResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.media_layout);

        editN01 = (EditText) findViewById(R.id.editN01);

        editN02 = (EditText) findViewById(R.id.editN02);

        editN03 = (EditText) findViewById(R.id.editN03);

        editN04 = (EditText) findViewById(R.id.editN04);

        txtResultado = findViewById(R.id.txtResultado);

    }

    public void media(View v)
    {
        int n01, n02, n03, n04, res;
        n01 = Integer.parseInt(editN01.getText().toString());
        n02 = Integer.parseInt(editN02.getText().toString());
        n03 = Integer.parseInt(editN03.getText().toString());
        n04 = Integer.parseInt(editN04.getText().toString());

        res = (n01 + n02 + n03 + n04)/ 4;

        if(res >= 6){
            txtResultado.setText("a média do aluno é: " +res+ " Ele esta Aprovado");
        } else if (res >= 4) {
            txtResultado.setText("a média do aluno é: " +res+ " Ele esta de Exame");
        } else {
            txtResultado.setText("a média do aluno é: " +res+ " Ele esta Reprovado");
        }
    }

}